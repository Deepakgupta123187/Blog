import React from "react";
import Posts from "./Posts";
import "./App.css";
function App() {
  return (
    <>
      <div className="main">
        <Posts />
      </div>
    </>
  );
}

export default App;
